from __future__ import division, print_function

# Flask utils
from flask import Flask, redirect, url_for, request, render_template

# Dates
from datetime import datetime, timedelta
import pytz

# REE API request
import requests
import json

# Convert extracted data into dataframe
import pandas as pd

# WindowGenerator
from window_generator import WindowGenerator
import numpy as np

# Loading the model
import tensorflow as tf
from tensorflow import keras

# Define a flask app
app = Flask(__name__)


def extract_json_data(day):
    URLprices = "https://apidatos.ree.es/es/datos/mercados/precios-mercados-tiempo-real"
    URLdemand = "https://apidatos.ree.es/es/datos/demanda/demanda-tiempo-real"
    URLEmissions = "https://apidatos.ree.es/es/datos/generacion/evolucion-estructura-generacion-emisiones-asociadas"

    startHour = "00:00"
    endHour = "23:59"

    date_start = str(day.year) + "-" + str(day.month) + "-" + str(day.day) + "T" + startHour
    date_end = str(day.year) + "-" + str(day.month) + "-" + str(day.day) + "T" + endHour

    PARAMS = {'start_date': date_start, 'end_date': date_end, "time_trunc": "hour", 'geo_limit': 'peninsular'}

    prices = requests.get(url=URLprices, params=PARAMS)
    demands = requests.get(url=URLdemand, params=PARAMS)
    emissions = requests.get(url=URLEmissions, params=PARAMS)

    pricesJ = json.dumps(prices.json(), indent=4)
    demandJ = json.dumps(demands.json(), indent=4)
    emissionsJ = json.dumps(emissions.json(), indent=4)
    
    # Check keys, otherwise substract one day and try again
    emissions_json = json.loads(emissionsJ)
    if('include' not in emissions_json.keys()):
        
        previous_day = day - timedelta(days=1)
        date_start = str(previous_day.year) + "-" + str(previous_day.month) + "-" + str(previous_day.day) + "T" + startHour
        date_end = str(previous_day.year) + "-" + str(previous_day.month) + "-" + str(previous_day.day) + "T" + endHour

        PARAMS = {'start_date': date_start, 'end_date': date_end, "time_trunc": "hour", 'geo_limit': 'peninsular'}
        
        emissions = requests.get(url=URLEmissions, params=PARAMS)
        emissionsJ = json.dumps(emissions.json(), indent=4)

    return pricesJ, demandJ, emissionsJ


def clean_datetime(timestamp):
    r = timestamp.replace(".000+01:00", "")
    r = r.replace(".000+02:00", "")
    return r


def convert_json_into_dataframe(price_json, demand_json, emissions_json, today=False):
    df_price = pd.DataFrame(columns=['timestamp', 'price'])
    df_demand = pd.DataFrame(columns=['timestamp', 'demand'])
    df_emissions = pd.DataFrame(columns=['timestamp', 'emissions'])

    # Generate price dataframe
    price_json = json.loads(price_json)
    prices_values = price_json['included'][0]['attributes']['values']
    for price_value in prices_values:
        row = {'timestamp': price_value['datetime'],
               'price': price_value['value']}
        df_price = df_price.append(row, ignore_index=True)

    # Generate demand dataframe
    demand_json = json.loads(demand_json)
    if (today):
        demand_values = demand_json['included'][1]['attributes']['values']
    else:
        demand_values = demand_json['included'][0]['attributes']['values']

    for demand_value in demand_values:
        row = {'timestamp': demand_value['datetime'],
               'demand': demand_value['value']}
        df_demand = df_demand.append(row, ignore_index=True)

    # Generate emissions dataframe
    emissions_json = json.loads(emissions_json)
    emissions_values = emissions_json['included'][0]['attributes']['values']

    for emissions_value in emissions_values:
        row = {'timestamp': emissions_value['datetime'],
               'emissions': emissions_value['value']}
        df_emissions = df_emissions.append(row, ignore_index=True)

    df_merged = df_price.merge(df_demand, on='timestamp', how='inner')

    df_emissions['timestamp'] = df_price['timestamp']
    df_merged = df_merged.merge(df_emissions, on='timestamp', how='inner')

    df_merged['timestamp'] = df_merged['timestamp'].apply(clean_datetime)

    # Separate two columns by " "
    df_merged[['date', 'time']] = df_merged['timestamp'].str.split('T', expand=True)

    df_merged = df_merged.drop(columns=['timestamp'], axis=1)

    return df_merged


def difference(dataset, interval=1):
    diff = list()
    for i in range(interval, len(dataset)):
        value = dataset[i] - dataset[i - interval]
        diff.append(value)
    return pd.Series(diff)


# Check http://127.0.0.1:5000/
@app.route('/', methods=['GET'])
def index():
    # Main page
    return '<html><h1>REE API</h1><p>Created by Juan Carlos Alonso Valenzuela and Vanessa Pradas Fernández</p><p>Use the endpoint /predict</p></html>'


@app.route('/predict', methods=['GET'])
def predict():
    timezone = pytz.timezone('Europe/Madrid')

    today = datetime.now(tz=timezone)
    tomorrow = today + timedelta(days=1)
    yesterday = today - timedelta(days=1)
    day_zero = yesterday - timedelta(days=1)

    pricesJ_today, demandJ_today, emissionsJ_today = extract_json_data(today)
    pricesJ_yesterday, demandJ_yesterday, emissionsJ_yesterday = extract_json_data(yesterday)
    pricesJ_day_zero, demandJ_day_zero, emissionsJ_day_zero = extract_json_data(day_zero)

    # day_zero
    df_final = convert_json_into_dataframe(pricesJ_day_zero, demandJ_day_zero, emissionsJ_day_zero)

    # yesterday
    df_yesterday = convert_json_into_dataframe(pricesJ_yesterday, demandJ_yesterday, emissionsJ_day_zero)
    # Repetimos las emisiones del día cero
    df_final = pd.concat([df_final, df_yesterday], ignore_index=True)

    # today
    df_today = convert_json_into_dataframe(pricesJ_today, demandJ_today, emissionsJ_day_zero, today=True)
    df_final = pd.concat([df_final, df_today], ignore_index=True)

    df = df_final

    df['data'] = df['date'] + " " + df['time']

    df['data'] = pd.to_datetime(df['data'])
    df = df.drop(columns=['date', 'time'], axis=1)
    df = df.set_index('data')

    # Used for removing differencing
    last_line = df.tail(n=1)
    initial_price = last_line['price'][0]
    initial_demand = last_line['demand'][0]
    initial_emissions = last_line['emissions'][0]


    # Normalization/Standarization params
    train_mean = pd.Series(data=[0.025869, -0.074058, 0.272317], index=['price', 'demand', 'emissions'])
    train_std = pd.Series(data=[22.190049, 1295.266304, 537.640099], index=['price', 'demand', 'emissions'])

    diff_price = difference(df['price'])
    diff_emissions = difference(df['emissions'])
    diff_demand = difference(df['demand'])

    s1 = pd.Series([0.0])
    diff_price = s1.append(diff_price, ignore_index=True)
    diff_emissions = s1.append(diff_emissions, ignore_index=True)
    diff_demand = s1.append(diff_demand, ignore_index=True)

    df['price'] = diff_price.values
    df['demand'] = diff_demand.values
    df['emissions'] = diff_emissions.values

    df = (df - train_mean) / train_std

    df = df[len(df) - 48:]

    # Fill labels with zeros
    L = 24
    i = 0
    while i < 24:
        i = i + 1
        last_date = df.index[-1] + pd.Timedelta(hours=1)
        df.loc[last_date] = [0.0, 0.0, 0.0]

    OUT_STEPS = 24
    multi_window = WindowGenerator(input_width=48, label_width=OUT_STEPS, shift=OUT_STEPS, train_df=df, test_df=df)

    example_window = tf.stack([
        np.array(df)
    ])

    example_inputs, example_labels = multi_window.split_window(example_window)

    multi_window.example = example_inputs, example_labels

    ar_model = keras.models.load_model('saved_model/')

    inputs, labels = multi_window.example

    # Each column is a different df column
    predictions = ar_model(inputs)

    price_predictions = np.array(predictions[0, :, 0])
    demand_predictions = np.array(predictions[0, :, 1])
    emissions_predictions = np.array(predictions[0, :, 2])

    # Normalization
    price_predictions = (price_predictions * train_std['price']) + train_mean['price']
    demand_predictions = (demand_predictions * train_std['demand']) + train_mean['demand']
    emissions_predictions = (emissions_predictions * train_std['emissions']) + train_mean['emissions']

    price_predictions[0] = initial_price + price_predictions[0]
    demand_predictions[0] = initial_demand + demand_predictions[0]
    emissions_predictions[0] = initial_emissions + emissions_predictions[0]

    for i in range(1, len(price_predictions)):
        price_predictions[i] = price_predictions[i - 1] + price_predictions[i]
        demand_predictions[i] = demand_predictions[i - 1] + demand_predictions[i]
        emissions_predictions[i] = emissions_predictions[i - 1] + emissions_predictions[i]

    return {
        'title': 'predictions for {}/{}/{} from 00:00 to 23:00'.format(tomorrow.day, tomorrow.month, tomorrow.year),
        'values': {
            'price_predictions': str(list(price_predictions)),
            'demand_predictions': str(list(demand_predictions)),
            'emissions_predictions': str(list(emissions_predictions))
        }
    }


if __name__ == '__main__':
    app.run(debug=True)
